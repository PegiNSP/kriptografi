package klasik;
public class SandiVigenere {
    public static String encrypt(String plaintext, String keyword) {
        StringBuilder ciphertext = new StringBuilder();
        int keywordLength = keyword.length();
        for (int i = 0; i < plaintext.length(); i++) {
            char ch = plaintext.charAt(i);
            if (Character.isLetter(ch)) {
                char keywordChar = keyword.charAt(i % keywordLength);
                int shift = Character.toUpperCase(keywordChar) - 'A';
                char encryptedChar = (char) ((ch - 'A' + shift) % 26 + 'A');
                ciphertext.append(encryptedChar);
            } else {
                ciphertext.append(ch);
            }
        }
        return ciphertext.toString();
    }
    
    public static String decrypt(String ciphertext, String keyword) {
        StringBuilder plaintext = new StringBuilder();
        int keywordLength = keyword.length();
        for (int i = 0; i < ciphertext.length(); i++) {
            char ch = ciphertext.charAt(i);
            if (Character.isLetter(ch)) {
                char keywordChar = keyword.charAt(i % keywordLength);
                int shift = Character.toUpperCase(keywordChar) - 'A';
                char decryptedChar = (char) ((ch - 'A' - shift + 26) % 26 + 'A');
                plaintext.append(decryptedChar);
            } else {
                plaintext.append(ch);
            }
        }
        return plaintext.toString();
    }
    
    public static void main(String[] args) {
        String plaintext = "HELLO";
        String keyword = "KEY";
        
        String ciphertext = encrypt(plaintext, keyword);
        System.out.println("Ciphertext: " + ciphertext);
        
        String decryptedText = decrypt(ciphertext, keyword);
        System.out.println("Decrypted text: " + decryptedText);
    }
}

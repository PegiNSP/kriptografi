package klasik;
import java.util.Arrays;
public class SandiHill {
    public static int[][] matrixMultiply(int[][] matrix1, int[][] matrix2) {
        int rows1 = matrix1.length;
        int cols1 = matrix1[0].length;
        int cols2 = matrix2[0].length;
        
        int[][] result = new int[rows1][cols2];
        
        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < cols2; j++) {
                for (int k = 0; k < cols1; k++) {
                    result[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }
        
        return result;
    }
    
    public static String encrypt(String plaintext, int[][] keyMatrix) {
        int blockSize = keyMatrix.length;
        int[] plainNums = new int[plaintext.length()];
        
        for (int i = 0; i < plaintext.length(); i++) {
            char ch = plaintext.charAt(i);
            plainNums[i] = ch - 'A';
        }
        
        StringBuilder ciphertext = new StringBuilder();
        int paddingLength = plaintext.length() % blockSize;
        if (paddingLength != 0) {
            paddingLength = blockSize - paddingLength;
        }
        
        for (int i = 0; i < paddingLength; i++) {
            plainNums = Arrays.copyOf(plainNums, plainNums.length + 1);
            plainNums[plainNums.length - 1] = 25; // Padding with 'Z'
        }
        
        for (int i = 0; i < plainNums.length; i += blockSize) {
            int[] block = Arrays.copyOfRange(plainNums, i, i + blockSize);
            int[][] blockMatrix = new int[blockSize][1];
            
            for (int j = 0; j < blockSize; j++) {
                blockMatrix[j][0] = block[j];
            }
            
            int[][] encryptedMatrix = matrixMultiply(keyMatrix, blockMatrix);
            
            for (int j = 0; j < blockSize; j++) {
                int encryptedNum = encryptedMatrix[j][0] % 26;
                char encryptedChar = (char) (encryptedNum + 'A');
                ciphertext.append(encryptedChar);
            }
        }
        
        return ciphertext.toString();
    }
    
    public static String decrypt(String ciphertext, int[][] keyMatrix) {
        int blockSize = keyMatrix.length;
        int[][] inverseKeyMatrix = getInverseMatrix(keyMatrix);
        
        int[] cipherNums = new int[ciphertext.length()];
        for (int i = 0; i < ciphertext.length(); i++) {
            char ch = ciphertext.charAt(i);
            cipherNums[i] = ch - 'A';
        }
        
        StringBuilder plaintext = new StringBuilder();
        
        for (int i = 0; i < cipherNums.length; i += blockSize) {
            int[] block = Arrays.copyOfRange(cipherNums, i, i + blockSize);
            int[][] blockMatrix = new int[blockSize][1];
            
            for (int j = 0; j < blockSize; j++) {
                blockMatrix[j][0] = block[j];
            }
            
            int[][] decryptedMatrix = matrixMultiply(inverseKeyMatrix, blockMatrix);
            
            for (int j = 0; j < blockSize; j++) {
                int decryptedNum = decryptedMatrix[j][0] % 26;
                char decryptedChar = (char) (decryptedNum + 'A');
                plaintext.append(decryptedChar);
            }
        }
        
        return plaintext.toString();
    }
    
    public static int[][] getInverseMatrix(int[][] matrix) {
        // Implementation to get the inverse of a matrix
        // This code assumes the matrix is invertible
        // You can use libraries like Apache Commons Math for a more robust implementation
        // Here, we'll just return the transpose matrix as an example
        
        int rows = matrix.length;
        int cols = matrix[0].length;
        
        int[][] inverseMatrix = new int[cols][rows];
        
        for (int i = 0; i < cols; i++) {
            for (int j = 0; j < rows; j++) {
                inverseMatrix[i][j] = matrix[j][i];
            }
        }
        
        return inverseMatrix;
    }
    
    public static void main(String[] args) {
        int[][] keyMatrix = {
            {2, 4},
            {1, 3}
        };
        
        String plaintext = "HELLO";
        
        String ciphertext = encrypt(plaintext, keyMatrix);
        System.out.println("Ciphertext: " + ciphertext);
        
        String decryptedText = decrypt(ciphertext, keyMatrix);
        System.out.println("Decrypted text: " + decryptedText);
    }
}

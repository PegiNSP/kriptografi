import java.math.BigInteger;
import java.util.Random;

public class RSA {
    private BigInteger p;
    private BigInteger q;
    private BigInteger n;
    private BigInteger phi;
    private BigInteger e;
    private BigInteger d;
    private static final int BIT_LENGTH = 1024;
    private static final int CERTAINTY = 100;
    private static final Random RANDOM = new Random();
    
    public RSA() {
        generateKeys();
    }
    
    public void generateKeys() {
        p = BigInteger.probablePrime(BIT_LENGTH, RANDOM);
        q = BigInteger.probablePrime(BIT_LENGTH, RANDOM);
        
        n = p.multiply(q);
        
        phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        
        do {
            e = new BigInteger(phi.bitLength(), RANDOM);
        } while (e.compareTo(BigInteger.ONE) <= 0 || e.compareTo(phi) >= 0 || !e.gcd(phi).equals(BigInteger.ONE));
        
        d = e.modInverse(phi);
    }
    
    public BigInteger encrypt(BigInteger plaintext) {
        return plaintext.modPow(e, n);
    }
    
    public BigInteger decrypt(BigInteger ciphertext) {
        return ciphertext.modPow(d, n);
    }
    
    public static void main(String[] args) {
        RSA rsa = new RSA();
        
        BigInteger plaintext = new BigInteger("123456789");
        
        BigInteger ciphertext = rsa.encrypt(plaintext);
        System.out.println("Ciphertext: " + ciphertext);
        
        BigInteger decryptedText = rsa.decrypt(ciphertext);
        System.out.println("Decrypted: " + decryptedText);
    }
}

